const menuButton = document.querySelector('[data-menu-button]');
const navLinks = document.querySelector('[data-nav-links]');
if (menuButton && navLinks) {
  menuButton.addEventListener('click', () => navLinks.classList.toggle('open'));
}
const search = document.querySelector('[data-project-search]');
if (search) {
  const cards = Array.from(document.querySelectorAll('[data-project-card]'));
  search.addEventListener('input', () => {
    const q = search.value.toLowerCase().trim();
    cards.forEach(card => {
      const text = card.innerText.toLowerCase() + ' ' + (card.dataset.tags || '').toLowerCase();
      card.style.display = text.includes(q) ? '' : 'none';
    });
  });
}
