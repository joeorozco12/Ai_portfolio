# Jose Orozco Applied AI Engineering Portfolio Site

This is a static website. No backend, no build step, no proprietary data.

## View locally

1. Download and unzip the folder.
2. Open `index.html` in Chrome, Edge, Safari, or Firefox.
3. Keep the folder structure intact so the CSS, JS, and data files load correctly.

## Publish options

- GitHub Pages: upload the full folder to a repository and enable Pages.
- Netlify: drag the unzipped folder into Netlify Drop.
- Vercel: import the repository or deploy as a static project.

## Safety notes

All examples are synthetic automotive-lighting examples. Do not add proprietary requirements, customer names, supplier documents, internal schematic screenshots, or confidential metrics.
