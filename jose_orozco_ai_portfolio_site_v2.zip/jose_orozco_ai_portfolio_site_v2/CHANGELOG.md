# Changelog

## v0.2

- Added complete CSS and JavaScript assets.
- Added six individual project case-study pages.
- Added governance and resume pages.
- Added synthetic CSV data examples.
- Added local viewing instructions.
